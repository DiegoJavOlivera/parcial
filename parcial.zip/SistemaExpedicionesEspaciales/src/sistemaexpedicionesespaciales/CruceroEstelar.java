/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaexpedicionesespaciales;

/**
 *
 * @author Diego
 */
public class CruceroEstelar extends Nave{
    private int cantidadPasajeros;

    public CruceroEstelar(int cantidadPasajeros, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String toString() {
        return "Carguero{" + "Nombre= " + getNombre() + "Capacidad Tripulacion=" + getCapacidadTripulacion()+ "Año de lanzamiento=" + getAnioLanzamiento() + "Cantidad Pasajeros" + cantidadPasajeros + '}';
    }

    
    
}
