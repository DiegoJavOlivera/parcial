/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemaexpedicionesespaciales;

/**
 *
 * @author Diego
 */
public class SistemaExpedicionesEspaciales {


    public static void main(String[] args) {
        Agencia agencia = new Agencia("AGENCIA ESPACIAL SPACE Y");
        
        NaveExploracion n1 = new NaveExploracion(TipoMision.CONTACTO, "STRONG", 150, 2025);
        Carguero n2 = new Carguero(300, "CHARGER", 200, 2030);
        Carguero n5 = new Carguero(350, "CHARGER", 20, 2030);
        Carguero n3 = new Carguero(450, "GIGANT", 100, 3000);
        CruceroEstelar n4 = new CruceroEstelar(150, "Turism", 50, 3500);
        Carguero nCargueroSobreCargado = new Carguero(550, "Warning", 400, 3502);
        
        try {
            agencia.agregarNave(n1);
            agencia.agregarNave(n2);
            agencia.agregarNave(n3);
            agencia.agregarNave(nCargueroSobreCargado);
            agencia.agregarNave(n5);
            agencia.agregarNave(n4);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } 
        
    }
    
}
